//
// Created by nadav on 12/27/18.
//

#include "Command.h"

Command::~Command(){
;
}
