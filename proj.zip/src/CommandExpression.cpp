//
// Created by nadav on 12/27/18.
//

#include "CommandExperssion.h"

CommandExpression::~CommandExpression(){
    delete command;
}
